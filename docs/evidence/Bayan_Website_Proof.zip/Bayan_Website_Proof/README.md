# Bayan — real website proof

This package uses screenshots of the actual Bayan website. No answer screens were recreated or rewritten.

## Start with these three showcases

### 1. Knowledge level

Show `knowledge-beginner-website.jpg` beside `knowledge-experienced-website.jpg`.

Beginner question:
> أنا لا أعرف شيئاً عن الإسلام. ما معنى التوحيد؟ اشرح لي ببساطة.

More experienced question:
> أعرف معنى التوحيد إجمالاً. كيف يشرح المصدر توحيد الربوبية والألوهية والأسماء والصفات؟

**Say:** “Bayan reads the question to understand the learner. It explains the basic idea for a beginner, and the three categories for someone who already knows the term.”

**Short Arabic caption:** يفهم مستوى السائل ويكيّف عمق الشرح.

The captured API analysis classifies these examples as beginner and intermediate. The website’s Level B badge describes the answer type, not the user’s knowledge level. Supporting original outputs are in `docs/submission/showcase/beginner.json` and `experienced.json`.

### 2. Regional localization

Show `localization-general-website.jpg` beside `localization-western-website.jpg`. Both display the actual selected audience and the same Arabic question:

> ما معنى الدعوة في الإسلام؟ وهل هي إجبار الآخرين على تغيير دينهم؟

**General:** starts with the religious meaning of Da‘wah.

**Western:** first explains the word, then addresses the concern about forced conversion.

Both preserve the central meaning and cite original sources. This comparison demonstrates a change in wording and explanation order.

**Say:** “We keep the religious meaning, while adapting how it is introduced to the audience.”

**Short Arabic caption:** المعنى محفوظ، وطريقة الشرح تتكيّف مع الجمهور.

### 3. Multilingual

Show `multilingual-website.jpg`, then `multilingual-arabic-website.jpg`.

Arabic question:
> لماذا يتوجه المسلمون نحو الكعبة؟

Selected output: English. Selected audience: Western. Bayan also provides the Arabic version, with source passages and links.

**Say:** “Ask in Arabic and receive an English explanation, with an Arabic companion and published source passages.”

**Short Arabic caption:** سؤال عربي، وإجابة بالإنجليزية والعربية، مع المصادر.

## The 12 competition examples

Open `TEST_MATRIX.md`. It explains every category in simple English and links to its real website screenshot. Keep the matrix to one deck slide. Keep the 12 individual screenshots as supporting evidence.

## Explain the processing time positively

Use `verification-stages-website.jpg`.

**Say:** “Bayan checks the question, retrieves approved evidence, reviews the answer and protects key terms before presenting it. The time supports a careful, traceable answer.”

This captured fresh website run reports 49.5 seconds, including 37.01 seconds for explanation and review and 7.85 seconds for evidence assessment. Other captures can reopen or reuse previously reviewed answers. Do not present those replay times as new answer-generation speed, or describe the safeguards as a guarantee of perfect accuracy.

## How to place these in the deck

1. Three showcase slides: knowledge, regional localization, multilingual.
2. One compact matrix slide for all 12 categories.
3. Use the real screenshot as the main visual. Add one short headline and one sentence.
4. In PowerPoint, crop the screenshot margins to enlarge the question and answer. Preserve the relevant audience selection, sources, and “saved answer” label.
5. Use purple accents and the proposal’s light/dark rhythm. Keep the original screenshots sharp; do not stretch them or replace their text.

The remaining 12 screenshot pages belong in the evidence package, not as 12 extra pitch slides. The full deck will be prepared in the organizer’s PowerPoint template in the next stage.

## Capture details

- Captured from the live local Bayan website at `http://127.0.0.1:8000/`.
- The saved-answer popup is Bayan’s real product interface, containing completed website results.
- Full screenshots are approximately Full HD: 1920×1080 or 1915×1077, as returned by the browser.
- `CAPTURE_MANIFEST.json` lists dimensions and SHA-256 fingerprints.
- No benchmark assertion, source text, application code or output was changed for these captures.
